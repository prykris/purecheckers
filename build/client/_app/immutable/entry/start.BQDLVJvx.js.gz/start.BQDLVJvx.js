import{l as o,a as r}from"../chunks/DWu77KBa.js";export{o as load_css,r as start};
